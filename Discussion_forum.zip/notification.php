<?php require("header.php");?>
<?php
echo "<h1> YOU ARE SUCCESSFULLY REGISTERED </h1> " ;
echo "To log-in <a href='login.php'>click here</a>";
?>
<?php require("footer.php");?>