<?php require_once("utility.php"); 
ob_start(); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html" charset="utf-8" />
<title>Everylady</title>
<link rel="stylesheet" type="text/css" href="font-awesome-4.6.3/css/font-awesome.min.css">
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
    <script src="lib/jquery.js" type="text/javascript"></script>
      <script src="src/facebox.js" type="text/javascript"></script>
      <link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>
<script src="runtime.js" type="text/javascript" charset="utf-8"></script>
        <link href="../_assets/themes/yui/style.css" rel="stylesheet" type="text/css" />
    <script src="../_assets/js/jquery-1.2.6.min.js" type="text/javascript"></script>        
    <script src="../_assets/js/jquery.wjb.selectallrows.js" type="text/javascript"></script>
    
<link href="themes/5/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/5/js-image-slider.js" type="text/javascript"></script>
   
      <script type="text/javascript">
        jQuery(document).ready(function($) {
          $('a[rel*=facebox]').facebox({
            loadingImage : 'src/loading.gif',
            closeImage   : 'src/closelabel.png'
          })
        })
      </script>
<script type="text/javascript" src="script.js"></script>

<link rel="stylesheet" href="res/style.css" type="text/css" media="screen" />
    <!--[if IE 6]><link rel="stylesheet" href="res/style.ie6.css" type="text/css" media="screen" /><![endif]-->
    <!--[if IE 7]><link rel="stylesheet" href="res/style.ie7.css" type="text/css" media="screen" /><![endif]-->
    
</head>

<body>

<div id="art-page-background-simple-gradient">
    </div>
    <div id="art-page-background-glare">
        <div id="art-page-background-glare-image"></div>
    </div>
    <div id="art-main">
        <div class="art-Sheet">
            <div class="art-Sheet-tl"></div>
            <div class="art-Sheet-tr"></div>
            <div class="art-Sheet-bl"></div>
            <div class="art-Sheet-br"></div>
            <div class="art-Sheet-tc"></div>
            <div class="art-Sheet-bc"></div>
            <div class="art-Sheet-cl"></div>
            <div class="art-Sheet-cr"></div>
            <div class="art-Sheet-cc"></div>
            <div class="art-Sheet-body">
                <p><img src="/userfiles/image/craftedkosher_22_02_2017_2.gif" width="890" height="43" hspace="4" alt="" /></p>
                <div class="art-Header">
                        <h1 id="name-text" class="art-Logo-name"><a href="#">Everylady</a></h1>
                        <h1 id="name-text1" class="art-Logo-name1"><a href="#">Unleashing female potential to change the world...</a></h1>
                   
<div style="position: absolute; height: 78px; width: 170px; left: 720px; top: 0; ">

Welcome!
We are an online community for women.
<a rel="facebox" href="register.php" >Click here to join us</a> (it's free)!

    <!--<form name="searchform" method="get" action="searchh.php?Result">
                <table width="175" height="70">
                    <tbody>
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="text" maxlength="300" size="23" name="q" style="color:#999;" value="Search......" onblur="if(this.value=='') this.value='Search......';" onfocus="if(this.value=='Search......') this.value='';"/></td>
                        </tr>
                        <tr>
                            <td align="right" width="25">
                            <div align="left"><span style="color: rgb(204, 255, 204);">
                                <input type="submit" name="submit" value="Go" />
                            </span>   </div> 
                            </td>
                        </tr>
                    </tbody>
                </table>
    </form> -->
</div>


                   <div class="art-Header-jpeg"></div>
                    <div class="art-Logo">
                    </div>
                </div><br>
                <div class="art-nav">
                	<div class="l"></div>
                	<div class="r"></div>
                	<ul class="art-menu">
                        
                        <li><a href="index.php" id="homee"><span class="l"></span><span class="r"></span><span class="t"><i class="fa fa-home fa-2x" style="color:#ffffff;"></i></span></a></li>
                        
                		<li><a href="uhome.php" id="auhome"><span class="l"></span><span class="r"></span><span class="t">Home</span></a></li>
                        
                		<li><a href="aboutus.php" id="aaboutus"><span class="l"></span><span class="r"></span><span class="t">About Us</span></a></li>
                		
                		<li><a href="forum.php" id="aforum"><span class="l" ></span><span class="r"></span><span class="t">Forum/Articles</span></a>
                			
                		<li><a href="contact.php" id="acontact"><span class="l"></span><span class="r"></span><span class="t">Contact Us</span></a></li>
                        
                        <li><a href="messages.php" id="amessage"><span class="l"></span><span class="r"></span><span class="t">Message</span></a></li>
                        
                        <li><a rel="facebox" href="register.php" ><span class="l"></span><span class="r"></span><span class="t">Join Now</span></a></li>

</ul>
<?php include("menu.php");?>
                </div>
                    
                      