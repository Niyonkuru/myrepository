<?php require("header.php");

?>

<script type="text/javascript">
	document.getElementById("auhome").className="active";
</script>

                <div class="art-contentLayout">
                    <div class="art-content">
                        <div class="art-Post">
                            <div class="art-Post-tl"></div>
                            <div class="art-Post-tr"></div>
                            <div class="art-Post-bl"></div>
                            <div class="art-Post-br"></div>
                            <div class="art-Post-tc"></div>
                            <div class="art-Post-bc"></div>
                            <div class="art-Post-cl"></div>
                            <div class="art-Post-cr"></div>
                            <div class="art-Post-cc"></div>
                            <div class="art-Post-body">
                        <div class="art-Post-inner">
`                            <h2 class="art-PostHeaderIcon-wrapper">
                                <img src="res/images/welcome.jpg" width="9" height="9" alt="PostHeaderIcon" />
                                <span class="art-PostHeader">Welcome</span>
                            </h2>
                            <div class="art-PostContent">
                                
                                
<p align="justify">Welcome to Everylady™. 
I, Amir, I created Everylady™.com because I felt that there was a need for a website geared to  women and mothers.</p>

<p>This website was born after I went searching in the vast expanses of the internet for some advice about raising our kids. I looked at the  forums of numerous parenting websites, but there just wasn't anything relevant to me, as a, Rwandan. Again I left my computer feeling like there was just a blank area where there should have been a place where I could share my thoughts and worries. I was looking for a place where I could meet more women just like me. I wanted a spot where my friends and I could go to share stories about our day. I wanted a website just like all the others but with a very important difference. I wanted it to be relevant to me as a married woman and as a mother. I wanted a place where there would be information about topics that are important to me. And where I could get advice from other women about whatever issue was bothering me at the moment.</p>

I searched and searched for this website, and when I found none, we decided to meet that need ourselves. We felt women all across the world deserved a place to connect, chat, share advice about raising kids and interacting with our husbands, and talk about issues that are important to us. Since we started we have undergone many changes. We even had a name change. We accepted advice from friends and family. We added links and removed others when we saw people didn't use them.</p>

<p>Slowly, slowly, with a lot of hard work, we made this website into what it is today. We want women to feel that there is a place online where they can connect and unite, give and receive advice from other  women, and learn new things. I hope this website will unite all  women across the world. Let us all be part of one online community.</p>

<p>If you have any suggestions or comments please feel free to email me at amirniy@Everylady.com </p> 

<p>Thanks for joining our online community and helping us take the internet to a whole new level.</p>

Sincerely,<br>

Amir Niyonkuru<br>

Legal Statement<br>

<p>Everylady™ is a trademark and a copyrighted composition. All content produced on Everylady.com is copyrighted by Everylady.com. </p>

<p>If you wish to publish or otherwise reproduce information from our website, whether online, in a periodical or book, please contact us. </p>

<p>This website is a library of user contributions. The administrators and moderators will attempt to remove objectionable material brought to their attention. However it is impossible to, and we do not, review every post. All posts made to these forums express the views and opinions of the contributors and not of the administrators or moderators. The adminstrators and moderators of Everylady.com will not be held responsible for the contents of posts, just like a library is not responsible for the content of books. </p>

<p>All advertisements and all content on advertised websites are subject to continuous review and approval by Everylady. All advertisements and all content on advertised websites must comply with strict  rules as commonly observed by  individuals and families. The promotion of another religion, sexually oriented material, and pictures of scantily clad persons, anywhere on an advertiser's website, are prohibited. If the presence of such prohibited and objectionable material on an advertised website was not noticed at the time of accepting an advertisement, Everylady reserves the right to instantly block and terminate the advertisement when such objectionable content is discovered, without advance notice. The unused portion of the prepaid advertising fee will then be refunded. The advertiser agrees that, in case of doubt, the Everylady administrator will be the sole decision maker. By advertising on our site, an advertiser agrees with and accepts this advertising and content policy, and agrees to hold Everylady harmless.</p>


                          
                                
                                   
                            </div>
                            <div class="cleared"></div>
                        </div>
                        
                            </div>
                        </div>
                    </div>
                    <?php include("sidebar1.php");?>
                  
                    <?php include("highlight.php");?>
                    </div>
                  </div>

<?php include('footer.php');?>
