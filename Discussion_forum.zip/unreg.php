<?php session_start();
 require("header.php");?>
 
 <h3>If you are  not a registered user!!!!<br/></h3>

<h2> <i class="fa fa-hand-o-right fa-1x" style="color:black;"></i> &nbsp;&nbsp;&nbsp;
<a rel="facebox" href="register.php">Register</a> /
<a href="login.php">Sign In</a>
 </h2>
 <?php require("footer.php");?>