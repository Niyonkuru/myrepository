<?php require_once("utility.php"); 
ob_start(); 
?>
<?php 
$sql="SELECT count(question_id) as Threads from question";
$result=ExecuteQuery($sql);
  while($row = mysql_fetch_array($result))
  {
  $thread = $row['Threads'];
  echo "Total Threads :$thread";                                
  }
?>
&nbsp;&nbsp;&nbsp;
<?php 
$sql="SELECT count(user_id) as Users from user";
$result=ExecuteQuery($sql);
  while($row = mysql_fetch_array($result))
  {
  $user = $row['Users'];
  echo "Members :$user";                                
  }
?>
&nbsp;&nbsp;&nbsp;
<?php 

$sql="SELECT count(user_id) as Online from user where isuser=true";
$rows=ExecuteQuery($sql);

if (mysql_num_rows($rows)>0)
{
while ($row = mysql_fetch_array ($rows))
{
    $onuser = $row['Online'];
  echo "Online Members :$onuser";
}
}
?>