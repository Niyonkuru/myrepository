<div class="cleared">
<hr />
 <table class="card_container" style="width:40px;float:left;">
  <tr class="card">
 <td><a class="side" href="https://www.facebook.com" target="_blank"><img src="res/images/facebook.png" /></a>
     <a class="side_back" href="https://www.facebook.com" target="_blank"><img src="res/images/facebook.png" /></a>
 </td>
  </tr>
  </table>

  <table class="card_container" style="width:40px;float:left;">
  <tr class="card">
 <td><a class="side" href="https://www.google.com" target="_blank"><img src="res/images/google.png" /></a>
     <a class="side_back" href="https://www.google.com" target="_blank"><img src="res/images/google.png" /></a>
 </td>
  </tr>
  </table>

    <table class="card_container" style="width:40px;float:left;">
  <tr class="card">
 <td><a class="side" href="htpps://www.twitter.com" target="_blank"> <img src="res/images/twitter.png" /></a>
     <a class="side_back" href="https://www.twitter.com" target="_blank"><img src="res/images/twitter.png" /></a>
 </td>
  </tr>
  </table>


    <table class="card_container" style="width:40px;float:left;">
  <tr class="card">
 <td><a class="side" href="https://www.linkedin.com" target="_blank"><img src="res/images/linkedin.png" /></a>
     <a class="side_back" href="https://www.linkedin.com" target="_blank"><img src="res/images/linkedin.png" /></a>
 </td>
  </tr>
  </table> 
  <div style="float:right;margin-top:20px;font-weight: lighter;">
  <?php include("thread.php");?>
  </div>
</div>
                <div class="art-Footer">
                    <div class="art-Footer-inner">
                        <div class="art-Footer-text">
                            <p><font color="black" size="1px">Everylady is a community of women, where you can come to relax, <br>
socialize, debate, receive support, ask questions and much more.</font><br>
                            <a href="contact.php">Contact Us</a> | <a href="terms.php">Terms of Use</a> 
                                | <a href="prvs.php">Privacy Statement</a> <br />
                                Copyright &copy; 2017 Everylady.com ---. All Rights Reserved.
                            </p>
                        </div>
                    </div>
                    <div class="art-Footer-background"></div>
                </div>
            </div>
        </div>
           
</body>

</html>
